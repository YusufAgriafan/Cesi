<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;

Route::get('/', [MainController::class, 'index'])->name('index');
Route::get('/home', [AdminController::class, 'index'])->name('index');
Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

Route::middleware('auth')->group(function () {
    Route::get('/permainan', [MainController::class, 'permainan'])->name('permainan');
    Route::get('/prediksi', [MainController::class, 'prediksi'])->name('prediksi');
   
});
Route::get('/informasi', [MainController::class, 'informasi'])->name('informasi');
Route::get('/team', [MainController::class, 'team'])->name('team');
Route::get('/detail', [MainController::class, 'detail'])->name('detail');
Route::get('/masukan', [MainController::class, 'masukan'])->name('masukan');
Route::get('/project', [MainController::class, 'project'])->name('project');

Route::fallback(function () {
    return view('404');
});