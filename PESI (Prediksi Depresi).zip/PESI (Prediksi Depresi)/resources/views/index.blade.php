
@extends('layout.master1')
@section('tittle', 'Pesi')

@section('content')

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4 align-items-end mb-4">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <img class="img-fluid rounded" src="img/about.jpg">
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">About Us</p>
                    <h1 class="display-5 mb-4">PESI memberi dukungan kesehatan mental kepada klien </h1>
                    <p class="mb-4">PESI berkomitmen untuk menjadi pendukung bagi mereka yang melawan depresi. Dengan pengalaman yang mendalam dalam bidang kesehatan mental, 
                        PESI berupaya untuk menyediakan sumber daya yang bermanfaat dan lingkungan yang mendukung bagi individu yang menghadapi tantangan ini.
                    </p>
                    <div class="border rounded p-4">
                        <nav>
                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                <button class="nav-link fw-semi-bold active" id="nav-story-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-story" type="button" role="tab" aria-controls="nav-story"
                                    aria-selected="true">Story</button>
                                <button class="nav-link fw-semi-bold" id="nav-mission-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-mission" type="button" role="tab" aria-controls="nav-mission"
                                    aria-selected="false">Mission</button>
                                <button class="nav-link fw-semi-bold" id="nav-vision-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-vision" type="button" role="tab" aria-controls="nav-vision"
                                    aria-selected="false">Vision</button>
                            </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-story" role="tabpanel"
                                aria-labelledby="nav-story-tab">
                                <p>Dengan laporan yang berasal dari World Health Organization (WHO) 2023 menunjukkan bahwa sekitar 280 juta orang di seluruh dunia mengalami depresi. </p>
                                <p class="mb-0">Ini menjadi pemicu utama untuk mendirikan website ini, yang bertujuan memberikan akses mudah dan sumber daya yang bermanfaat bagi individu yang menghadapi tantangan kesehatan mental. </p>
                            </div>
                            <div class="tab-pane fade" id="nav-mission" role="tabpanel"
                                aria-labelledby="nav-mission-tab">
                                <p>★ Memberikan akses mudah dan informatif kepada individu yang menghadapi depresi.</p>
                                <p class="mb-0">★ Menyediakan informasi mendalam tentang depresi, termasuk gejala, penyebab, dan strategi pengelolaan.</p><br>
                                <p>★ Memperkuat ketahanan mental dan membantu individu merasa didengar, didukung, dan diarahkan menuju pemulihan yang positif.</p>
                            </div>
                            <div class="tab-pane fade" id="nav-vision" role="tabpanel" aria-labelledby="nav-vision-tab">
                                <p>➛ Menjadi sumber utama bagi individu yang menghadapi depresi.</p>
                                <p class="mb-0">➛ Menyediakan harapan, dukungan, dan sumber daya yang diperlukan.</p><br>
                                <p class="mb-0">➛ Membantu individu mencapai kesejahteraan mental yang berkelanjutan.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border rounded p-4 wow fadeInUp" data-wow-delay="0.1s">
                <div class="row g-4">
                    <div class="col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                        <div class="h-100">
                            <div class="d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-primary">
                                    <i class="fa fa-times text-white"></i>
                                </div>
                                <div class="ps-3">
                                    <h4>No Hidden Cost</h4>
                                    <span>Clita erat ipsum lorem sit sed stet duo justo</span>
                                </div>
                                <div class="border-end d-none d-lg-block"></div>
                            </div>
                            <div class="border-bottom mt-4 d-block d-lg-none"></div>
                        </div>
                    </div>
                    <div class="col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                        <div class="h-100">
                            <div class="d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-primary">
                                    <i class="fa fa-users text-white"></i>
                                </div>
                                <div class="ps-3">
                                    <h4>Dedicated Team</h4>
                                    <span>Clita erat ipsum lorem sit sed stet duo justo</span>
                                </div>
                                <div class="border-end d-none d-lg-block"></div>
                            </div>
                            <div class="border-bottom mt-4 d-block d-lg-none"></div>
                        </div>
                    </div>
                    <div class="col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                        <div class="h-100">
                            <div class="d-flex">
                                <div class="flex-shrink-0 btn-lg-square rounded-circle bg-primary">
                                    <i class="fa fa-phone text-white"></i>
                                </div>
                                <div class="ps-3">
                                    <h4>24/7 Available</h4>
                                    <span>Clita erat ipsum lorem sit sed stet duo justo</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <!-- Facts Start -->
    <div class="container-fluid facts my-5 py-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.1s">
                    <i class="fa fa-users fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Happy Clients</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.3s">
                    <i class="fa fa-check fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Projects Completed</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.5s">
                    <i class="fa fa-users-cog fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Dedicated Staff</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
                <div class="col-sm-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.7s">
                    <i class="fa fa-award fa-3x text-white mb-3"></i>
                    <h1 class="display-4 text-white" data-toggle="counter-up">1234</h1>
                    <span class="fs-5 text-white">Awards Achieved</span>
                    <hr class="bg-white w-25 mx-auto mb-0">
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->


    <!-- Features Start -->
    <div class="container-xxl feature py-5">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Why Choosing Us!</p>
                    <h1 class="display-5 mb-4">Beberapa alasan kenapa orang memilih PESI</h1>
                    <!-- <p class="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et
                        eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet
                    </p>
                    <a class="btn btn-primary py-3 px-5" href="">Explore More</a> -->
                </div>
                <div class="col-lg-6">
                    <div class="row g-4 align-items-center">
                        <div class="col-md-6">
                            <div class="row g-4">
                                <div class="col-12 wow fadeIn" data-wow-delay="0.3s">
                                    <div class="feature-box border rounded p-4">
                                        <i class="fa fa-check fa-3x text-primary mb-3"></i>
                                        <h4 class="mb-3">Komitmen pada Kesehatan Mental</h4>
                                        <p class="mb-3">PESI memahami pentingnya kesehatan mental dan berkomitmen untuk menyediakan dukungan yang diperlukan bagi mereka yang menghadapi tantangan ini.</p>
                                    </div>
                                </div>
                                <div class="col-12 wow fadeIn" data-wow-delay="0.5s">
                                    <div class="feature-box border rounded p-4">
                                        <i class="fa fa-check fa-3x text-primary mb-3"></i>
                                        <h4 class="mb-3">Keterbukaan dan Keamanan</h4>
                                        <p class="mb-3">PESI menjaga kerahasiaan dan keamanan informasi pribadi Anda dengan sangat serius. Anda dapat merasa nyaman untuk berbagi pengalaman Anda di platform kami tanpa takut akan kebocoran atau penyalahgunaan informasi.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 wow fadeIn" data-wow-delay="0.7s">
                            <div class="feature-box border rounded p-4">
                                <i class="fa fa-check fa-3x text-primary mb-3"></i>
                                <h4 class="mb-3">Kemudahan Akses</h4>
                                <p class="mb-3">Platform ini dirancang dengan pemikiran tentang kemudahan akses. Anda dapat mengakses sumber daya dan dukungan kami kapan saja dan di mana saja, melalui perangkat apa pun yang Anda gunakan.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Features End -->


    <!-- Service Start -->
    <div class="container-xxl service py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Our Fitur</p>
                <h1 class="display-5 mb-5">Fitur Informasi PESI</h1>
            </div>
            <div class="row g-4 wow fadeInUp" data-wow-delay="0.3s">
                <div class="col-lg-4">
                    <div class="nav nav-pills d-flex justify-content-between w-100 h-100 me-4">
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-4 active"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-1" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Gejala Depresi</h5>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-4"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-2" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Pencegahan Depresi</h5>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-4"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-3" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Cara Penanganan Depresi</h5>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-0"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-4" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Informasi Terpercaya</h5>
                        </button>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content w-100">
                        <div class="tab-pane fade show active" id="tab-pane-1">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-1.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-4">Temukan daftar lengkap gejala depresi yang umum, termasuk perubahan mood, 
                                        gangguan tidur, dan pikiran negatif, serta informasi tentang bagaimana mengenali dan mengatasi gejala tersebut.
</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Perubahan Mood</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Gangguan Tidur</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Pikiran Negatif</p>
                                    <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-2">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-2.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <br><br><br>
                                    <p class="mb-4">Pelajari tentang langkah-langkah yang dapat Anda ambil untuk mengurangi risiko terkena depresi 
                                        atau mencegah kambuhnya kondisi ini, termasuk tips gaya hidup sehat dan strategi manajemen stres.</p>
                                    <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-3">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-3.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <br><br><br>
                                    <p class="mb-4">Temukan berbagai pendekatan untuk mengelola depresi, 
                                        mulai dari pengobatan medis hingga terapi dan dukungan sosial, serta saran praktis untuk memulai perjalanan pemulihan.</p>
                                    <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-4">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-4.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <br><br>
                                    <p class="mb-4">Dapatkan informasi yang akurat dan terpercaya tentang depresi dari sumber yang dapat dipercaya, disusun oleh ahli kesehatan mental.
Manfaatkan konten yang terperinci dan mendalam untuk meningkatkan pemahaman Anda tentang depresi dan langkah-langkah yang dapat Anda ambil untuk mengatasi kondisi ini.</p>
                                    <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4 align-items-end mb-4">
                <div class="col-lg-5 wow fadeInUp" data-wow-delay="0.1s">
                    <img class="img-fluid rounded" src="img/about.jpg">
                </div>
                <div class="col-lg-7 wow fadeInUp" data-wow-delay="0.3s">
                    <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Our Fitur</p>
                    <h1 class="display-5 mb-4">Fitur Kuis</h1>
                    <p class="mb-4">Selamat datang di Fitur Kuis PESI! Kami menyajikan kuis singkat yang dirancang untuk menguji pengetahuan Anda tentang kesehatan mental, termasuk depresi, 
                        kecemasan, dan manajemen stres. Kuis ini adalah cara yang menyenangkan dan interaktif untuk mengevaluasi pemahaman Anda tentang topik-topik ini dan memperdalam wawasan Anda tentang kesehatan mental secara umum.
                    </p>
                    <div class="border rounded p-4">
                        <nav>
                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                <button class="nav-link fw-semi-bold active" id="nav-edukasi-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-edukasi" type="button" role="tab" aria-controls="nav-edukasi"
                                    aria-selected="true">Edukasi</button>
                                <button class="nav-link fw-semi-bold" id="nav-evaluasi-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-evaluasi" type="button" role="tab" aria-controls="nav-evaluasi"
                                    aria-selected="false">Evaluasi Diri</button>
                                <button class="nav-link fw-semi-bold" id="nav-sumber-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-sumber" type="button" role="tab" aria-controls="nav-sumber"
                                    aria-selected="false">sumber Daya Tambahan</button>
                            </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-edukasi" role="tabpanel"
                                aria-labelledby="nav-edukasi-tab">
                                <p>Tingkatkan pengetahuan Anda tentang kesehatan mental secara menyenangkan dan interaktif.</p>
                            </div>
                            <div class="tab-pane fade" id="nav-evaluasi" role="tabpanel"
                                aria-labelledby="nav-evaluasi-tab">
                                <p>Evaluasi pemahaman Anda tentang topik kesehatan mental dan identifikasi area yang perlu diperbaiki.</p>
                            </div>
                            <div class="tab-pane fade" id="nav-sumber" role="tabpanel" aria-labelledby="nav-sumber-tab">
                                <p>Temukan sumber daya tambahan untuk memperdalam pemahaman Anda tentang topik-topik kesehatan mental yang penting.</p>
                            </div>
                        </div>
                    </div>
                    <br>
                    <a class="btn btn-primary py-3 px-5" href="">Explore More</a>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Service Start -->
    <div class="container-xxl service py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Our Fitur</p>
                <h1 class="display-5 mb-5">Mini Game</h1>
            </div>
            <div class="row g-4 wow fadeInUp" data-wow-delay="0.3s">
                <div class="col-lg-4">
                    <div class="nav nav-pills d-flex justify-content-between w-100 h-100 me-4">
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-4 active"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-5" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Memory Game</h5>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-4"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-6" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Teka-Teki Blok</h5>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start border p-4 mb-4"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-7" type="button">
                            <h5 class="m-0"><i class="fa fa-bars text-primary me-3"></i>Harmoni</h5>
                        </button>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content w-100">
                        <div class="tab-pane fade show active" id="tab-pane-5">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-1.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="border rounded p-4">
                                        <nav>
                                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                                <button class="nav-link fw-semi-bold active" id="nav-deskripsi1-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-deskripsi1" type="button" role="tab" aria-controls="nav-deskripsi1"
                                                    aria-selected="true">Deskripsi</button>
                                                <button class="nav-link fw-semi-bold" id="nav-tujuan1-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-tujuan1" type="button" role="tab" aria-controls="nav-tujuan1"
                                                    aria-selected="false">tujuan</button>
                                                <button class="nav-link fw-semi-bold" id="nav-carakerja1-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-carakerja1" type="button" role="tab" aria-controls="nav-carakerja1"
                                                    aria-selected="false">Cara kerja</button>
                                            </div>
                                        </nav>
                                        <div class="tab-content" id="nav-tabContent">
                                            <div class="tab-pane fade show active" id="nav-deskripsi1" role="tabpanel"
                                                aria-labelledby="nav-deskripsi1-tab">
                                                <p class="mb-4">Permainan Memori (Memory Game) adalah sebuah permainan yang dirancang untuk mengasah fokus dan konsentrasi pengguna dengan mencocokkan pasangan kartu yang tersembunyi. 
                                        Permainan ini memiliki tujuan utama untuk penanggulangan dan pencegahan depresi, dengan memberikan aktivitas yang menyenangkan dan menenangkan yang dapat membantu mengurangi gejala depresi dan kecemasan. 
                                        Selain itu, isi dari kartu-kartu ini akan mencakup informasi tentang gejala depresi dan cara penanggulangannya, yang bertujuan untuk meningkatkan kesadaran pengguna mengenai kesehatan mental mereka.</p>
                                                <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                            </div>
                                            <div class="tab-pane fade" id="nav-tujuan1" role="tabpanel"
                                                aria-labelledby="nav-tujuan1-tab">
                                                <p><i class="fa fa-check text-primary me-3"></i>Penanggulangan Depresi</p>
                                                <p><i class="fa fa-check text-primary me-3"></i>Pencegahan Depresi</p>
                                                <p><i class="fa fa-check text-primary me-3"></i>Melatih Daya Ingat dan Konsentrasi</p>
                                            </div>
                                            <div class="tab-pane fade" id="nav-carakerja1" role="tabpanel" aria-labelledby="nav-carakerja1-tab">
                                                <p>1.  Mulai Permainan</p>
                                                <p class="mb-0">2. Kartu akan ditampilkan secara tertutup dalam bentuk grid</p><br>
                                                <p>3. Setiap kartu memiliki pasangan identik yang tersembunyi di antara kartu-kartu lainnya. Isi kartu mencakup informasi tentang gejala depresi dan cara penanggulangannya.</p>
                                                <p class="mb-0">4.  Pengguna dapat memilih dua kartu dalam setiap giliran dengan mengkliknya. Kartu yang dipilih akan terbuka dan menampilkan gambar serta informasi yang ada di baliknya.</p><br>
                                                <p>5. Jika dua kartu yang dipilih memiliki gambar dan informasi yang sama, kartu tersebut akan tetap terbuka dan dianggap sebagai pasangan yang cocok.</p>
                                                <p class="mb-0">6. Jika kartu yang dipilih tidak cocok, kartu tersebut akan kembali tertutup setelah beberapa detik, memungkinkan pengguna untuk mencoba lagi.</p><br>
                                                <p>7. Jumlah giliran yang dilakukan pengguna akan dihitung dan ditampilkan di layar. Semakin sedikit giliran yang dibutuhkan untuk mencocokkan semua pasangan, semakin baik performa pengguna.</p>
                                                <p class="mb-0">8. Permainan selesai ketika semua pasangan kartu berhasil dicocokkan.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-6">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-2.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="border rounded p-4">
                                        <nav>
                                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                                <button class="nav-link fw-semi-bold active" id="nav-deskripsi-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-deskripsi" type="button" role="tab" aria-controls="nav-deskripsi"
                                                    aria-selected="true">Deskripsi</button>
                                                <button class="nav-link fw-semi-bold" id="nav-tujuan-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-tujuan" type="button" role="tab" aria-controls="nav-tujuan"
                                                    aria-selected="false">Tujuan</button>
                                                <button class="nav-link fw-semi-bold" id="nav-carakerja-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-carakerja" type="button" role="tab" aria-controls="nav-carakerja"
                                                    aria-selected="false">Cara Kerja</button>
                                            </div>
                                        </nav>
                                        <div class="tab-content" id="nav-tabContent">
                                            <div class="tab-pane fade show active" id="nav-deskripsi" role="tabpanel"
                                                aria-labelledby="nav-deskripsi-tab">
                                                <p class="mb-4">Teka-Teki Blok adalah permainan yang dirancang untuk melatih kemampuan berpikir strategis dan spasial Anda. Dengan antarmuka yang sederhana namun menantang, game ini mengajak Anda untuk menyusun blok-blok dengan cara yang benar agar sesuai dan mengisi ruang yang tersedia. 
                                        Permainan ini tidak hanya menyenangkan tetapi juga dapat berkontribusi pada peningkatan kesehatan mental Anda.</p>
                                                <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                            </div>
                                            <div class="tab-pane fade" id="nav-tujuan" role="tabpanel"
                                                aria-labelledby="nav-tujuan-tab">
                                                <p><i class="fa fa-check text-primary me-3"></i>Meningkatkan fokus dan konsentrasi.</p>
                                                <p><i class="fa fa-check text-primary me-3"></i>Mengembangkan kemampuan pemecahan masalah</p>
                                                <p><i class="fa fa-check text-primary me-3"></i>Mengalihkan pikiran dari stres dan kecemasan sehari-hari.</p>
                                            </div>
                                            <div class="tab-pane fade" id="nav-carakerja" role="tabpanel" aria-labelledby="nav-carakerja-tab">
                                                <p>1.  Mulai Permainan</p>
                                                <p class="mb-0">2. Akan diberikan sejumlah blok dengan bentuk yang berbeda</p><br>
                                                <p>3. Seret dan letakkan blok-blok tersebut ke dalam grid permainan untuk mengisi ruang yang kosong.</p>
                                                <p class="mb-0">4. Akan diberikan sejumlah blok dengan bentuk yang berbeda</p><br>
                                                <p>5. Tujuannya adalah untuk mengisi seluruh grid dengan blok-blok tanpa menyisakan ruang kosong.</p>
                                                <p class="mb-0">6. Jika berhasil menyelesaikan grid, akan diberikan poin</p>
                                            </div>
                                        </div>
                                    </div>                                   
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-7">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute rounded w-100 h-100" src="img/service-3.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="border rounded p-4">
                                        <nav>
                                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                                <button class="nav-link fw-semi-bold active" id="nav-deskripsi2-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-deskripsi2" type="button" role="tab" aria-controls="nav-deskripsi2"
                                                    aria-selected="true">Deskripsi</button>
                                                <button class="nav-link fw-semi-bold" id="nav-tujuan2-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-tujuan2" type="button" role="tab" aria-controls="nav-tujuan2"
                                                    aria-selected="false">Tujuan</button>
                                                <button class="nav-link fw-semi-bold" id="nav-carakerja2-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-carakerja2" type="button" role="tab" aria-controls="nav-carakerja2"
                                                    aria-selected="false">Cara Kerja</button>
                                            </div>
                                        </nav>
                                        <div class="tab-content" id="nav-tabContent">
                                            <div class="tab-pane fade show active" id="nav-deskripsi2" role="tabpanel"
                                                aria-labelledby="nav-deskripsi2-tab">
                                                <p class="mb-4">Harmoni adalah permainan yang terinspirasi dari Mahjong, dirancang khusus untuk mengkombinasikan dua tile yang sama. Game ini menantang dan menenangkan, mengajak Anda untuk menemukan pasangan tile yang serupa untuk menghapusnya dari papan. 
                                        Permainan ini tidak hanya mengasyikkan, tetapi juga memiliki manfaat untuk kesehatan mental Anda.
                                        Permainan ini tidak hanya menyenangkan tetapi juga dapat berkontribusi pada peningkatan kesehatan mental Anda.</p>
                                                <a href="" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
                                            </div>
                                            <div class="tab-pane fade" id="nav-tujuan2" role="tabpanel"
                                                aria-labelledby="nav-tujuan2-tab">
                                                <p><i class="fa fa-check text-primary me-3"></i>Pengalihan Pikiran</p>
                                                <p><i class="fa fa-check text-primary me-3"></i>Stimulasi Kognitif</p>
                                                <p><i class="fa fa-check text-primary me-3"></i>Kepuasan Emosional</p>
                                            </div>
                                            <div class="tab-pane fade" id="nav-carakerja2" role="tabpanel" aria-labelledby="nav-carakerja2-tab">
                                                <p>1.  Mulai Permainan</p>
                                                <p class="mb-0">2. Cari dan klik dua tile yang sama untuk mengkombinasikannya dan menghapusnya dari papan permainan.</p><br>
                                                <p>3. Hanya tile yang tidak terhalang oleh tile lainnya yang dapat dipilih.</p>
                                                <p class="mb-0">4. Tujuannya adalah untuk menghapus semua tile dari papan dengan menemukan semua pasangan yang cocok.</p><br>
                                                <p>5. Tujuannya adalah untuk mengisi seluruh grid dengan blok-blok tanpa menyisakan ruang kosong.</p>
                                                <p class="mb-0">6. Setelah semua pasangan ditemukan dan dihapus, game selesai dengan skor yang ditampilkan</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->  

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4 align-items-end mb-4">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Our Fitur</p>
                    <h1 class="display-5 mb-4">Cek Depresi</h1>
                    <p class="mb-4">Selamat datang di Fitur Cek Depresi PESI, alat yang dirancang untuk membantu Anda mengevaluasi dan memahami tingkat depresi Anda. 
                        Fitur ini menyediakan penilaian singkat yang dapat membantu Anda memprediksi apakah mungkin mengalami kondisi ini berdasarkan kondisi Anda.
                    </p>
                    <div class="border rounded p-4">
                        <nav>
                            <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
                                <button class="nav-link fw-semi-bold active" id="nav-cara-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-cara" type="button" role="tab" aria-controls="nav-cara"
                                    aria-selected="true">Cara Kerja</button>
                                <button class="nav-link fw-semi-bold" id="nav-teknologi-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-teknologi" type="button" role="tab" aria-controls="nav-teknologi"
                                    aria-selected="false">Teknologi</button>
                            </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-cara" role="tabpanel"
                                aria-labelledby="nav-cara-tab">
                                <p>Isi kuesioner singkat yang mencakup berbagai pertanyaan</p>
                                <p>Setelah menyelesaikan kuesioner, Anda akan diberikan hasil penilaian yang menunjukkan tingkat kemungkinan Anda mengalami depresi, 
                                    serta saran berdasarkan skor Anda.</p>
                            </div>
                            <div class="tab-pane fade" id="nav-teknologi" role="tabpanel"
                                aria-labelledby="nav-teknologi-tab">
                                <p><i class="fa fa-check text-primary me-3"></i>Artificial Intelligent</p>
                                <p><i class="fa fa-check text-primary me-3"></i>Machine Learning</p>
                                <p><i class="fa fa-check text-primary me-3"></i>Fuzzy Naive Bayes</p>
                            </div>
                        </div>
                    </div>
                    <br>
                    <a class="btn btn-primary py-3 px-5" href="">Explore More</a><br><br>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <img class="img-fluid rounded" src="img/about.jpg">
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Callback Start -->
    <div class="container-fluid callback my-5 pt-5">
        <div class="container pt-5">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="bg-white border rounded p-4 p-sm-5 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                            <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Get In Touch
                            </p>
                            <h1 class="display-5 mb-5">Request A Call-Back</h1>
                        </div>
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="name" placeholder="Your Name">
                                    <label for="name">Your Name</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" id="mail" placeholder="Your Email">
                                    <label for="mail">Your Email</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="mobile" placeholder="Your Mobile">
                                    <label for="mobile">Your Mobile</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="subject" placeholder="Subject">
                                    <label for="subject">Subject</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" placeholder="Leave a message here" id="message"
                                        style="height: 100px"></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <button class="btn btn-primary w-100 py-3" type="submit">Submit Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Callback End -->


    <!-- Projects Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Our Projects</p>
                <h1 class="display-5 mb-5">We Have Completed Latest Projects</h1>
            </div>
            <div class="owl-carousel project-carousel wow fadeInUp" data-wow-delay="0.3s">
                <div class="project-item pe-5 pb-5">
                    <div class="project-img mb-3">
                        <img class="img-fluid rounded" src="img/service-1.jpg" alt="">
                        <a href=""><i class="fa fa-link fa-3x text-primary"></i></a>
                    </div>
                    <div class="project-title">
                        <h4 class="mb-0">Financial Planning</h4>
                    </div>
                </div>
                <div class="project-item pe-5 pb-5">
                    <div class="project-img mb-3">
                        <img class="img-fluid rounded" src="img/service-2.jpg" alt="">
                        <a href=""><i class="fa fa-link fa-3x text-primary"></i></a>
                    </div>
                    <div class="project-title">
                        <h4 class="mb-0">Cash Investment</h4>
                    </div>
                </div>
                <div class="project-item pe-5 pb-5">
                    <div class="project-img mb-3">
                        <img class="img-fluid rounded" src="img/service-3.jpg" alt="">
                        <a href=""><i class="fa fa-link fa-3x text-primary"></i></a>
                    </div>
                    <div class="project-title">
                        <h4 class="mb-0">Financial Consultancy</h4>
                    </div>
                </div>
                <div class="project-item pe-5 pb-5">
                    <div class="project-img mb-3">
                        <img class="img-fluid rounded" src="img/service-4.jpg" alt="">
                        <a href=""><i class="fa fa-link fa-3x text-primary"></i></a>
                    </div>
                    <div class="project-title">
                        <h4 class="mb-0">Business Loans</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Projects End -->


    <!-- Team Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Our Team</p>
                <h1 class="display-5 mb-5">Exclusive Team</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item">
                        <img class="img-fluid rounded" src="img/team-1.jpg" alt="">
                        <div class="team-text">
                            <h4 class="mb-0">Kate Winslet</h4>
                            <div class="team-social d-flex">
                                <a class="btn btn-square rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square rounded-circle mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item">
                        <img class="img-fluid rounded" src="img/team-2.jpg" alt="">
                        <div class="team-text">
                            <h4 class="mb-0">Jac Jacson</h4>
                            <div class="team-social d-flex">
                                <a class="btn btn-square rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square rounded-circle mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item">
                        <img class="img-fluid rounded" src="img/team-3.jpg" alt="">
                        <div class="team-text">
                            <h4 class="mb-0">Doris Jordan</h4>
                            <div class="team-social d-flex">
                                <a class="btn btn-square rounded-circle mx-1" href=""><i
                                        class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square rounded-circle mx-1" href=""><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square rounded-circle mx-1" href=""><i
                                        class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Testimonial Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center mx-auto wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <p class="d-inline-block border rounded text-primary fw-semi-bold py-1 px-3">Testimonial</p>
                <h1 class="display-5 mb-5">What Our Clients Say!</h1>
            </div>
            <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.3s">
                <div class="testimonial-item">
                    <div class="testimonial-text border rounded p-4 pt-5 mb-5">
                        <div class="btn-square bg-white border rounded-circle">
                            <i class="fa fa-quote-right fa-2x text-primary"></i>
                        </div>
                        Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem
                        lorem magna ut et, nonumy et labore et tempor diam tempor erat.
                    </div>
                    <img class="rounded-circle mb-3" src="img/testimonial-1.jpg" alt="">
                    <h4>Client Name</h4>
                    <span>Profession</span>
                </div>
                <div class="testimonial-item">
                    <div class="testimonial-text border rounded p-4 pt-5 mb-5">
                        <div class="btn-square bg-white border rounded-circle">
                            <i class="fa fa-quote-right fa-2x text-primary"></i>
                        </div>
                        Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem
                        lorem magna ut et, nonumy et labore et tempor diam tempor erat.
                    </div>
                    <img class="rounded-circle mb-3" src="img/testimonial-2.jpg" alt="">
                    <h4>Client Name</h4>
                    <span>Profession</span>
                </div>
                <div class="testimonial-item">
                    <div class="testimonial-text border rounded p-4 pt-5 mb-5">
                        <div class="btn-square bg-white border rounded-circle">
                            <i class="fa fa-quote-right fa-2x text-primary"></i>
                        </div>
                        Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem
                        lorem magna ut et, nonumy et labore et tempor diam tempor erat.
                    </div>
                    <img class="rounded-circle mb-3" src="img/testimonial-3.jpg" alt="">
                    <h4>Client Name</h4>
                    <span>Profession</span>
                </div>
                <div class="testimonial-item">
                    <div class="testimonial-text border rounded p-4 pt-5 mb-5">
                        <div class="btn-square bg-white border rounded-circle">
                            <i class="fa fa-quote-right fa-2x text-primary"></i>
                        </div>
                        Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem
                        lorem magna ut et, nonumy et labore et tempor diam tempor erat.
                    </div>
                    <img class="rounded-circle mb-3" src="img/testimonial-4.jpg" alt="">
                    <h4>Client Name</h4>
                    <span>Profession</span>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->

@endsection