<?php echo e($slot); ?>

<?php /**PATH E:\Pemrograman\Project\Pesi\Test\PESI\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>